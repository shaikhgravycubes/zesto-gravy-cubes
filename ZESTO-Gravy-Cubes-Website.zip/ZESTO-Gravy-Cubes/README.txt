ZESTO Gravy Cubes - Free Netlify deployment

1. Extract this ZIP.
2. Open Netlify Drop: https://app.netlify.com/drop
3. Log in to Netlify.
4. Drag the extracted ZESTO-Gravy-Cubes folder onto the drop area.
5. Netlify will give you a live .netlify.app URL.

Important:
- Replace the illustrative CSS product visuals with your real product photos when available.
- The contact form opens WhatsApp to +91 88289 08930.
- Contact email: fawaz.shaikh.440@gmail.com
- Location: Mankhurd, Mumbai, Maharashtra
